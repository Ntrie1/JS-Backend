exports.SECRET = '5f1db90283c991962c9ff81d34aa2fd3fa016981';

exports.paymentMethodMap = {
    "crypto-wallet": "Crypto Wallet",
    "credit-card": "Credit Card", 
    "debit-card": "Debit Card",
    "paypal": "Paypal", 
}
